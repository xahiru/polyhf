bower install --save vaadin/vaadin-grid@v3.0.0-alpha2
bower install neon-animation #if not, no ripple effect n paper-buttons look dead
bower install web-animations-js #not sure
bower install paper-button
bower install iron-form
bower install paper-input
bower install paper-item
bower install paper-listbox
bower install paper-dropdown-menu
bower install paper-radio-group
bower install paper-checkbox
//rest bower install