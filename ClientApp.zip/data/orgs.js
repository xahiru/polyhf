[
  {
    "orgname": "Org1",
  },
  {
    
    "orgname": "Org2",
  }
]