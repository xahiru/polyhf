[
  {
    "type": "po",
    "details": [{
                  "name": "Lisptick101",
                  "amount": 10,
                  "total": 1232,
                  "batches": [{
                    "batch": 1,
                    "amount": 3,
                    "pending": 7,
                    "delivered": 0,
                    "received": 0,
                    "price": 210,
                    "status": 1

                  },
                  {
                    "batch": 12,
                    "amount": 2,
                    "pending": 5,
                    "delivered": 0,
                    "received": 0,
                    "price": 210,
                    "status": 1
                  }
                  ] 
                },
                {
                  "name": "FoundationBB",
                  "amount": 100,
                  "total": 1232,
                  "batches": [{
                    "batch": 200,
                    "amount": 51,
                    "pending": 49,
                    "delivered": 0,
                    "received": 0,
                    "price": 40,
                    "status": 2

                  }]
                }
                ]
                  
    },
    {
    "type": "po",
    "details": [{
                  "name": "PrimerSetting Spra",
                  "amount": 10,
                  "total": 1232,
                  "batches": [{
                    "batch": 1,
                    "amount": 3,
                    "pending": 7,
                    "delivered": 0,
                    "received": 0,
                    "price": 20,
                    "status": 4

                  }]  
                },
                {
                  "name": "MascaraEyeliner",
                  "amount": 200,
                  "total": 1232,
                  "batches": [{
                    "batch": 4,
                    "amount": 50,
                    "pending": 150,
                    "delivered": 0,
                    "received": 0,
                    "price": 80,
                    "status": 3

                  }]
                }
                ]
    }

]
