[
  {
    "userId": 1,
    "createdBy": "retailer1",
    "type": "retailer",
    "items": [ 
      {
        "itemId": 111,
        "quantity": 12 
      },
      
      {
        "itemId": 112,
        "quantity": 12 
      },
       {
      "itemId": 124,
      "quantity": 12 
    }]
  },

  {
    "userId": 2,
    "createdBy": "retailer1",
    "type": "retailer",
    "items": [ 
      {
        "itemId": 114,
        "quantity": 12 
      },
      
      {
        "itemId": 115,
        "quantity": 12 
      }]
  }
  ]