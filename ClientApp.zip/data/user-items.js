[
  {
    "type": "item",
    "details": {
      "name": "Lisptick101",
      "amount": 2,
      "price": 210
    }
  },
  {
    "type": "item",
    "details": {
      "name": "FoundationBB",
      "amount": 40,
      "price": 10
    }
  }
]