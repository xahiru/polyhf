[
  {
    "userId": 1,
    "name": "Wall Mart101",
    "type": "retailer",
    "description": "Huanshang branch"
  },
  {
    "userId": 2,
    "name": "Carrafour",
    "type": "retailer",
    "description": "Zhuantang"
  },
  {
    "userId": 3,
    "name": "dist1",
    "type": "distributor",
    "description": "marketing dealer"
  },
  {
    "userId": 4,
    "name": "purchasing",
    "type": "NFSQ",
    "description": "order validator"
  },
  {
    "userId": 5,
    "name": "user2",
    "type": "NFSQ",
    "description": "factory"
  }
]