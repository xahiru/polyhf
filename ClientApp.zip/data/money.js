[
  {
    "type": "money",
    "details": {
      "name": "RMB",
      "amount": 50000
    }
  },
  {
    "type": "money",
    "details": {
      "name": "USD",
      "amount": 10000
    }
  }
]