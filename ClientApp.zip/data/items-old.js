[
  {
    "itemId": 111,
    "name": "Lisptick101",
    "units": "100"
  },
  {
    "itemId": 101,
    "name": "FoundationBB",
    "units": "100"
  },
  {
    "itemId": 112,
    "name": "PrimerSetting Spray",
    "units": "100"
  },
  {
    "itemId": 123,
    "name": "MascaraEyeliner",
    "units": "100"
  },
  {
    "itemId": 115,
    "name": "BlushBronzer",
    "units": "100"
  },
  {
    "itemId": 113,
    "name": "Cheek Palettes",
    "units": "101"
  },
  {
    "itemId": 114,
    "name": "Eyelashes",
    "units": "100"
  }
]