[
  {
    "type": "po",
    "details": {
                  "poid": 1,
                  "batch": 'batchID'
                  "amount": 7100
                  "statust": "Create"
                  "items": [{
                              "type": "item",
                              "details": {
                                "name": "Lisptick101",
                                "amount": 10,
                                "price": 210
                              }
                            },
                            {
                              "type": "item",
                              "details": {
                                "name": "FoundationBB",
                                "amount": 100,
                                "price": 50
                              }
                            }]
                  }
    },
    {
    "type": "po",
    "details": {
                  "poid": 2,
                  "batch": 'batchID'
                  "amount": 2000
                  "statust": "Create"
                  "items": [{
                              "type": "item",
                              "details": {
                                "name": "PrimerSetting Spra",
                                "amount": 10,
                                "price": 20
                              }
                            },
                            {
                              "type": "item",
                              "details": {
                                "name": "MascaraEyeliner",
                                "amount": 200,
                                "price": 80
                              }
                            }]
                  }
    }

]
