[
  {
    "type": "po",
    "details": [{
                  "name": "Lisptick101",
                  "amount": 10  
                },
                {
                  "name": "FoundationBB",
                  "amount": 100
                }
                ]
                  
    },
    {
    "type": "po",
    "details": [{
                  "name": "PrimerSetting Spra",
                  "amount": 10  
                },
                {
                  "name": "MascaraEyeliner",
                  "amount": 200
                }
                ]
    }

]
