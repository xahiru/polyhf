[
  {
    "type": "item",
    "details": {
      "name": "Lisptick101",
      "amount": 10,
      "price": 210
    }
  },
  {
    "type": "item",
    "details": {
      "name": "FoundationBB",
      "amount": 100,
      "price": 50
    }
  },
  {
    "type": "item",
    "details": {
      "name": "PrimerSetting Spra",
      "amount": 100,
      "price": 20
    }
  },
  {
    "type": "item",
    "details": {
      "name": "MascaraEyeliner",
      "amount": 100,
      "price": 80
    }
  },
  {
    "type": "item",
    "details": {
      "name": "BlushBronzer",
      "amount": 100,
      "price": 29
    }
  },
  {
    "type": "item",
    "details": {
      "name": "Cheek Palette",
      "amount": 100,
      "price": 30
    }
  },
  {
    "type": "item",
    "details": {
      "name": "Eyelashes",
      "amount": 100,
      "price": 32
    }
  }
]