[
  {
    "username": "alice",
    "orgname": "ORG1",
    "role": "user"
  },
  {
    "username": "bob",
    "orgname": "ORG1",
    "role": "user"
  },
  {
    "username": "charlie",
    "orgname": "ORG2",
    "role": "user"
  }
]